


def enable(exaile):
    print "Hello, world!"


def disable(exaile):
    print "Goodbye. :("


